#!/bin/bash

workd=$(pwd)
for i in 0 0.25 0.75 1 ; do
    cd $workd/$i
    echo "entring to dir $i "
    echo "<========================start=====================>"
    /usr/bin/mpirun --use-hwthread-cpus pw.x -inp c001.in 2>&1 | tee c001.out
    echo "<========================done=====================>"
    date
done